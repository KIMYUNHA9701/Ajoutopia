package com.example.crux16_ajou;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class FirstpageActivity extends AppCompatActivity {

    private Button qna;
    private Button study;
    private Button posting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firstpage);

        qna = (Button) findViewById(R.id.qna);
        study = (Button) findViewById(R.id.study);
        posting = (Button) findViewById(R.id.posting);

        qna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FirstpageActivity.this, FirstpageActivity.class);
                startActivity(intent);
            }
        });
        study.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FirstpageActivity.this, FirstpageActivity.class);
                startActivity(intent);
            }
        });
        posting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FirstpageActivity.this, FirstpageActivity.class);
                startActivity(intent);
            }
        });
    }
}
